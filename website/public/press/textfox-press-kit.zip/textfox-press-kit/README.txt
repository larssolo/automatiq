TextFox press kit
=================
www.textfox.app/creators  ·  hello@textfox.app

Free to use in content about TextFox. Please don't alter the logo or use it
for other products. Write the name as "TextFox" in sentences.

Contents
- logo/      textfox-logo-on-dark.png, textfox-logo-on-light.png,
             textfox-mark.svg (the fox), textfox-app-tile.svg / -1024.png,
             textfox-app-icon.svg (square), textfox-banner-1024x500.png
- screens/   six screenshots, 1080x2400 PNG
- Films (download from the website): www.textfox.app/creators#kit

Colours: Fox green #00C853 · Signal green #00E676 · Ink #090B0A · Paper #EEF3EF
Fonts:   DM Sans (text), JetBrains Mono (the "textfox" wordmark, labels)

Short (EN)
TextFox is an Android app that sends your text messages for you: on a
schedule, as an auto-reply, after a missed call or with one tap on a widget.
Set it up once, and it just runs.

Long (EN)
TextFox puts your everyday texts on autopilot. Send good morning at 08:00 on
weekdays, reply automatically when you're busy, text people back when you
miss their call, or send "running late" with one tap from your home screen.
Optional AI writes a fresh version of each message with your own free Google
Gemini key. Everything runs on your phone, with no account, no ads and no
tracking. Free for 30 days, then a one-time purchase. www.textfox.app

Kort (DA)
TextFox er en Android-app, der sender dine sms'er for dig: på et fast
tidspunkt, som autosvar, efter et ubesvaret opkald eller med ét tryk på en
widget. Sæt det op én gang, så kører det bare.

Lang (DA)
TextFox sætter dine faste sms'er på autopilot. Send godmorgen kl. 08.00 på
hverdage, svar automatisk når du har travlt, send en sms tilbage når du
misser et opkald, eller send "jeg er forsinket" med ét tryk fra
hjemmeskærmen. Valgfri AI skriver en ny version af hver besked med din egen
gratis Google Gemini-nøgle. Alt kører på din telefon, uden konto, reklamer
eller sporing. Gratis i 30 dage, derefter et engangskøb. www.textfox.app
